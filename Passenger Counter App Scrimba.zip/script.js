let countEl = document.getElementById("count-el")
let count = 0;

$(`#increment-btn`).on(`click`, function(){
    count= count+ 1;
    $(`#count-el`).text(count);
});


let username = "per"
let message = "You have tree new notifications"


let welcomeEl = document.getElementById("welcome-el");

let name = "Hello Thomas";
let greeting = "Welcome back";
$(welcomeEl).text(`${name} ${greeting}`);



let saveEl = $(`#save-el`);
$(`#save-btn`).on(`click`, function(){
    let countStr = count;
    $(saveEl).text(`People entered: ${countStr}`);
    $(countEl).text(0);
    count = 0
});